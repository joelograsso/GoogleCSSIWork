// const add = (num1, num2) => {
//   return num1 + num2
// }
//
//
//
// //
// // const myFunction = () => {
// //   console.log("I am here. Happy Thursday")
// // }
//
// // setInterval(myFunction, 2000);
//
//
// setInterval(() => {
//   console.log("rock");
// }, 1005)
//put stuff in here
let array = ["Red Wings", "Lions", "Tigers", "Pistons"]

const end = (phrase) => {
  return phrase;
}

for (let index = 0; index < array.length; index++){
  console.log(array[index] + end(" are the best"));
}
